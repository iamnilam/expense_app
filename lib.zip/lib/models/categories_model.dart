class CategoryModel {
  CategoryModel({
    required this.catId,
    required this.catTitle,
    required this.catImgPath,
  });

  int catId;
  String catTitle;
  String catImgPath;
}
